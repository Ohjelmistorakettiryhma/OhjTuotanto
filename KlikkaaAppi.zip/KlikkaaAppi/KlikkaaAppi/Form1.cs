﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace KlikkaaAppi
{
    public partial class FrmPoistamisAppi : Form
    {
        public FrmPoistamisAppi()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
       
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void tuoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void vieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void lopetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            Text = richTb.Text;
     
        }
        private void tsbtn1_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("c:\\temp\\teksti.txt");

            sr.Close();
        }

        private void tsbtn2_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("c:\\temp\\teksti.txt");
            
            sw.Write(richTb.Text);

            sw.Close();
        }

        private void tsbtn3_Click(object sender, EventArgs e)
        {
            richTb.Text = Text;

            richTb.Text.Replace(tsbpoistettavateksti);
        }

        private void tsbpoistettavateksti_Click(object sender, EventArgs e)
        {
            tsbpoistettavateksti.Text = Text;
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
