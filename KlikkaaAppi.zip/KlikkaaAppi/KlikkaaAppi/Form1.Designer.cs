﻿namespace KlikkaaAppi
{
    partial class FrmPoistamisAppi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPoistamisAppi));
            this.panel1 = new System.Windows.Forms.Panel();
            this.richTb = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbtn2 = new System.Windows.Forms.ToolStripButton();
            this.tsbpoistettavateksti = new System.Windows.Forms.ToolStripTextBox();
            this.tsbtn1 = new System.Windows.Forms.ToolStripButton();
            this.tsbtn3 = new System.Windows.Forms.ToolStripButton();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.richTb);
            this.panel1.Location = new System.Drawing.Point(87, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(613, 317);
            this.panel1.TabIndex = 0;
            // 
            // richTb
            // 
            this.richTb.Location = new System.Drawing.Point(186, 45);
            this.richTb.Name = "richTb";
            this.richTb.Size = new System.Drawing.Size(223, 193);
            this.richTb.TabIndex = 1;
            this.richTb.Text = "";
            this.richTb.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtn1,
            this.tsbtn2,
            this.tsbpoistettavateksti,
            this.tsbtn3});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 27);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // tsbtn2
            // 
            this.tsbtn2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtn2.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn2.Image")));
            this.tsbtn2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn2.Name = "tsbtn2";
            this.tsbtn2.Size = new System.Drawing.Size(29, 24);
            this.tsbtn2.Text = "toolStripButton1";
            this.tsbtn2.Click += new System.EventHandler(this.tsbtn2_Click);
            // 
            // tsbpoistettavateksti
            // 
            this.tsbpoistettavateksti.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tsbpoistettavateksti.Name = "tsbpoistettavateksti";
            this.tsbpoistettavateksti.Size = new System.Drawing.Size(100, 27);
            this.tsbpoistettavateksti.Click += new System.EventHandler(this.tsbpoistettavateksti_Click);
            // 
            // tsbtn1
            // 
            this.tsbtn1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtn1.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn1.Image")));
            this.tsbtn1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn1.Name = "tsbtn1";
            this.tsbtn1.Size = new System.Drawing.Size(29, 24);
            this.tsbtn1.Text = "toolStripButton2";
            this.tsbtn1.Click += new System.EventHandler(this.tsbtn1_Click);
            // 
            // tsbtn3
            // 
            this.tsbtn3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtn3.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn3.Image")));
            this.tsbtn3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn3.Name = "tsbtn3";
            this.tsbtn3.Size = new System.Drawing.Size(29, 24);
            this.tsbtn3.Text = "toolStripButton3";
            this.tsbtn3.Click += new System.EventHandler(this.tsbtn3_Click);
            // 
            // FrmPoistamisAppi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "FrmPoistamisAppi";
            this.Text = "ToolStripEsim";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.RichTextBox richTb;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbtn1;
        private System.Windows.Forms.ToolStripButton tsbtn2;
        private System.Windows.Forms.ToolStripTextBox tsbpoistettavateksti;
        private System.Windows.Forms.ToolStripButton tsbtn3;
    }
}

